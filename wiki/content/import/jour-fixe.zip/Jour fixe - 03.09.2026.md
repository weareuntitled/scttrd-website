# Jour fixe · 03.09.2026

> Beispielseite mit aktuellem Stand (Stand: 28.08.2026). Im Call befüllen, danach im Wiki lassen
> und für den nächsten Termin eine neue Seite nach **TEMPLATE** anlegen.

---

## Metadaten

- **Datum:** 03.09.2026
- **Zeit / Dauer:** _(noch offen — Vorschlag 14:30–16:00)_
- **Ort / Link:** _(Google-Meet-Link)_
- **Teilnehmer:** Daniel · Babsi · Nate

---

## 1 · Check-in (max. 2 Min/Person)

| Person | Seit letztem fertig | Als Nächstes dran | Blockiert durch | Entscheidung nötig |
|---|---|---|---|---|
| Daniel | _(_) | _(_) | _(_) | _(_) |
| Babsi | _(_) | _(_) | _(_) | _(_) |
| Nate | _(_) | _(_) | _(_) | _(_) |

---

## 2 · Bereichs-Updates (kurz: Stand / Blockiert / Nächster Schritt)

### Release
- **Stand:** „Wo du bist" — Release 11.09. **gestrichen** (Upload-Fenster 21.08. verpasst); Mixing läuft, Mastering offen.
  „Seele verloren" — finaler Track, Mix/Master + Cover noch offen.
- **Blockiert durch:** Mix/Master-Kapazität (→ Entscheidung intern vs. extern), Termin ohne 3-Wochen-Puffer nicht festsetzen.
- **Nächster Schritt:** [_] Neuen Release-Termin mit Puffer festlegen · [_] Master-Weg entscheiden (Budget: erste Priorität)
- **Neu:** _(neue Tracks/Beats)_

### Booking & Live
- **Stand:** By-On-Electro **angenommen** (25.08.). Deep Dive WE 25.–27.09. Alteglofsheim (Pflicht),
  Begrüßungs-WE 20.–22.11., Coachingwoche 11.–15.01.2027. Zugvogel-Anfrage (Nate) offen.
- **Blockiert durch:** Terminbestätigungen + Buchungen für Alteglofsheim.
- **Nächster Schritt:** [_] Verfügbarkeit zum 25.09. fixen · [_] Unterkunft/Fahrt buchen (Babsi) ·
  [_] Zugvogel nachziehen · [_] 2027-Bewerbungen starten (Nate)

### Content & Sichtbarkeit
- **Stand:** Wurzi-Videos (Matzes) halb viral → Reel dran; Babsi postet; Trial-Reels (Daniel) möglich.
- **Blockiert durch:** HD-Videos fehlen (WhatsApp-komprimiert), Bodypack (kabellos) noch nicht da.
- **Nächster Schritt:** [_] HD-Material anfordern · [_] Reel(s) in Metricool planen · [_] Sticker/Merch-Ecke fürs nächste Gig

### Admin & Finanzen
- **Stand:** Bandkasse aktiv (Wurzi 700 €, ~100 € Videograf). Drive-Speicher voll, Umzug offen.
- **Blockiert durch:** —
- **Nächster Schritt:** [_] GEMA-Meldung für kommende Releases vorsehen (Babsi) · [_] Drive-Umzug & Ordnerlogik (Nate)

---

## 3 · Offene Punkte / Blocker-Diskussion

- **Wo du bist:** neuer realistischer Release-Termin + Master-Entscheidung (intern vs. extern).
- **Alteglofsheim 25.–27.09.:** Anreise/Unterkunft / wer darf wann hin.
- **Booking 2027:** wer startet welche Bewerbungen bis wann.

---

## 4 · Retro Mini (optional, ~5 Min)

- **Gut:** _
- **Schlecht:** _
- **Take-Away / ändern:** _

---

## 5 · Decision Log / Action Items

| Entscheidung / Task | Owner | Deadline / Termin | Status / Follow-up |
|---|---|---|---|
| BYON Deep Dive 25.–27.09. bestätigen + ggf. absagen | Babsi | bis 02.09. | Termin steht im Kalender |
| „Wo du bist" neuen Release-Termin festlegen | Daniel | beim Jour fixe | Upload ≥ 3 Wochen vorher |
| Master-Weg entscheiden (extern/intern) | Daniel | beim Jour fixe | Budget ggf. freigeben |
| Zugvogel-Anfrage nachverfolgen | Nate | 10.09. | Antwort offen |

---

## 6 · Parking Lot

- _(Rider-Überarbeitung, Homepage-Update, Merch — bewusst nicht heute.)_

## 7 · Nächster Jour fixe

- **Datum/Uhrzeit:** _(_)_ · **Link:** _(_)__