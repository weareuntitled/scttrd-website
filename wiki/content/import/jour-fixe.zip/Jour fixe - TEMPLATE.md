# Jour fixe · TEMPLATE

> **So benutzen:** Pro Termin eine Kopie dieser Seite anlegen und als Namen
> **„Jour fixe · TT.MM.JJJJ"** vergeben. Während des Calls direkt in die Felder schreiben.
> Feste Struktur (Scrum-artig), sonst nichts ändern. Jeder Punkt endet mit
> **Entscheidung · Owner · Deadline · nächstem Schritt.**

---

## Metadaten

- **Datum:** _(TT.MM.JJJJ)_
- **Zeit / Dauer:** _(z. B. 14:30–16:00, 90 Min)_
- **Ort / Link:** _(Gasteig, bei Dani, Google-Meet …)_
- **Teilnehmer:** Daniel · Babsi · Nate

---

## 1 · Check-in (max. 2 Min/Person)

Die vier Fragen — immer dieselben:

| Person | Seit letztem fertig | Als Nächstes dran | Blockiert durch | Entscheidung nötig |
|---|---|---|---|---|
| Daniel |  |  |  |  |
| Babsi |  |  |  |  |
| Nate |  |  |  |  |

---

## 2 · Bereichs-Updates (kurz: Stand / Blockiert / Nächster Schritt)

### Release
- **Stand:** _(Wo du bist: Mix läuft, Termin gestrichen · Seele verloren: Freeze/Mix/Master)_
- **Blockiert durch:**
- **Nächster Schritt:**
- **Neu** _(neue Tracks/Beats)_:

### Booking & Live
- **Stand:** _(By-On-Electro, Gigs, 2027-Bewerbungen)_
- **Blockiert durch:**
- **Nächster Schritt:**

### Content & Sichtbarkeit
- **Stand:** _(Reels, Instagram/Stories, Metricool)_
- **Blockiert durch:**
- **Nächster Schritt:**

### Admin & Finanzen
- **Stand:** _(GEMA, Bandkasse, Drive, Homepage)_
- **Blockiert durch:**
- **Nächster Schritt:**

---

## 3 · Offene Punkte / Blocker-Diskussion

- _(Die 1–2 Punkte, die jetzt entschieden werden müssen — nicht alles, nur die Top-3.)_

---

## 4 · Retro Mini (optional, ~5 Min)

- **Gut:** _
- **Schlecht:** _
- **Take-Away / ändern:** _

---

## 5 · Decision Log / Action Items

Nur Entscheidungen, die nach dem Call relevant bleiben.

| Entscheidung / Task | Owner | Deadline / Termin | Status / Follow-up |
|---|---|---|---|
|  |  |  |  |

---

## 6 · Parking Lot

_(Alles, was die Timebox sprengt — wird ge-, nicht gelöst.)_

## 7 · Nächster Jour fixe

- **Datum/Uhrzeit:** _(_)_ · **Link:** _(_)__